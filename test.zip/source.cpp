#include <iostream>
#include <windows.h>
#include <ctime>
#include <fstream>
#include <conio.h>
#include <string>
#include <math.h>
#include <ctime>
using namespace std;
time_t now;
bool update = 0;
struct COURSE_DATA;
struct Node_course;
struct Node_semester;
struct SINHVIEN;
struct Node_student;
struct Node_class;
struct Node_year;
struct teacher;
// Các hàm làm giao diện
void gotoXY(SHORT posX, SHORT posY)
{
	HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD Position;
	Position.X = posX - 1;
	Position.Y = posY - 1;

	SetConsoleCursorPosition(hStdout, Position);
}
void textColor(int color)
{
	HANDLE hConsoleColor;
	hConsoleColor = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hConsoleColor, color);
}
void print_Login_logo(int x1, int y1)
{
	textColor(11);
	gotoXY(x1, ++y1);
	cout << " .----------------.  .----------------.  .----------------.  .----------------.  .----------------.";
	gotoXY(x1, ++y1);
	cout << "| .--------------. || .--------------. || .--------------. || .--------------. || .--------------. |";
	gotoXY(x1, ++y1);
	cout << "| |   _____      | || |     ____     | || |    ______    | || |     _____    | || | ____  _____  | |";
	gotoXY(x1, ++y1);
	cout << "| |  |_   _|     | || |   .'    `.   | || |  .' ___  |   | || |    |_   _|   | || ||_   \\|_   _| | |";
	gotoXY(x1, ++y1);
	cout << "| |    | |       | || |  /  .--.  \\  | || | / .'   \\_|   | || |      | |     | || |  |   \\ | |   | |";
	gotoXY(x1, ++y1);
	cout << "| |    | |   _   | || |  | |    | |  | || || |     ____  | || |      | |     | || |  | |\\ \\| |   | |";
	gotoXY(x1, ++y1);
	cout << "| |   _| |__/ |  | || |  \\  `--'  /  | || | \\ `.___]  _| | || |     _| |_    | || | _| |_\\   |_  | |";
	gotoXY(x1, ++y1);
	cout << "| |  |________|  | || |   `.____.'   | || |  `._____.'   | || |    |_____|   | || ||_____|\\____| | |";
	gotoXY(x1, ++y1);
	cout << "| |              | || |              | || |              | || |              | || |              | |";
	gotoXY(x1, ++y1);
	cout << "| '--------------' || '--------------' || '--------------' || '--------------' || '--------------' |";
	gotoXY(x1, ++y1);
	cout << " '----------------'  '----------------'  '----------------'  '----------------'  '----------------'";
	textColor(15);

}
void print_Viennen(int length, int width)
{
	//Tren cung
	for (int x = 2; x < length; x++)
	{
		gotoXY(x, 1);
		cout << char(220);
	}
	//Ben phai
	for (int y = 2; y <= width; y++)
	{
		gotoXY(length - 1, y);
		cout << char(219);
	}
	//Ben trai
	for (int y = 2; y <= width; y++)
	{
		gotoXY(2, y);
		cout << char(219);
	}
	//Duoi cung
	for (int x = 2; x < length; x++)
	{
		gotoXY(x, width);
		cout << char(223);
	}
}
void print_duongthang(int x1, int y1, int length)
{
	for (int y = 2; y < length + y1; y++)
	{
		gotoXY(x1, y);
		cout << char(219);
	}
}
void print_duongngang(int x1, int y1, int lenght)
{
	for (int x = x1; x < lenght + x1; x++)
	{
		gotoXY(x, y1);
		cout << char(220);
	}
}
void print_fill_square(int x1, int y1, int length, int width, int color, string text)
{
	gotoXY(x1 + ((length - 2) - text.length()) / 2 + 1, width / 2 + y1);
	cout << text;
	textColor(color);
	//Tren cung
	for (int x = x1; x < x1 + length; x++)
	{
		gotoXY(x, y1 - 1);
		cout << char(220);
	}
	//Ben phai
	for (int y = y1; y <= y1 + width; y++)
	{
		gotoXY(x1 + length - 1, y);
		cout << char(219);
	}
	//Ben trai
	for (int y = y1; y <= y1 + width; y++)
	{
		gotoXY(x1, y);
		cout << char(219);
	}
	//Duoi cung
	for (int x = x1; x < x1 + length; x++)
	{
		gotoXY(x, y1 + width);
		cout << char(223);
	}
	textColor(15);
}
void print_double_square(int x1, int y1, int length, int width, int color, string text)
{
	gotoXY(x1 + ((length - 2) - text.length()) / 2 + 1, width / 2 + y1);
	cout << text;
	textColor(color);
	//Tren cung
	for (int x = x1; x < x1 + length; x++)
	{
		gotoXY(x, y1 - 1);
		if (x == x1)
			cout << char(201);
		if (x == x1 + length - 1)
			cout << char(187);
		else
			cout << char(205);
	}
	//Ben phai
	for (int y = y1; y <= y1 + width; y++)
	{
		gotoXY(x1 + length - 1, y);
		cout << char(186);
	}
	//Ben trai
	for (int y = y1; y <= y1 + width; y++)
	{
		gotoXY(x1, y);
		cout << char(186);
	}
	//Duoi cung
	for (int x = x1; x < x1 + length; x++)
	{
		gotoXY(x, y1 + width);
		if (x == x1)
			cout << char(200);
		if (x == x1 + length - 1)
			cout << char(188);
		else
			cout << char(205);
	}
	textColor(15);
}
void print_type_in_box(int x1, int y1, string text, int size)
{
	print_double_square(x1, y1, text.length() + 2, 3, 15, text);
	print_double_square(x1 + text.length() + 2, y1, size, 3, 15, "\0");
	gotoXY(x1 + 2 + text.length() + 2, y1 + 1);
}
void text(int x, int y, string text, bool led, int color)
{
	if (led) textColor(color);
	gotoXY(x, y);
	cout << text;
	if (led) textColor(15);
}
// Các struct node
struct COURSE_DATA
{
	//course id, course name, teacher name, number of credits, the maximum number of students in the course(default 50), day of the week, and the session that the course will be performed(MON / TUE / WED / THU / FRI / SAT, S1(07:30), S2(09:30), S3(13:30) and S4(15:30)).A course will be taught in 2 sessions in a week
	string id, course_name, teacher_name, session1, session2;
	int number_of_credits, max_num_student, days_of_week;
};
struct Node_course
{
	double final = 0;
	double midterm = 0;
	double total = 0;
	double other = 0;
	COURSE_DATA data;
	Node_course* course_next = nullptr;
	Node_student* ph_student_enrolled = nullptr;
};
struct Node_semester
{

	/*int start_date, end_date;
	int regis_start, regis_end;*/
	string semester_no;
	Node_course* ph_course = nullptr;
	Node_semester* semester_next = nullptr;
};
struct SINHVIEN
{
	string No, ID, first_name, lastname, gender, social_ID, password, date;
};
struct Node_student
{
	SINHVIEN data;
	Node_student* student_next = nullptr;
	Node_course* ph_course_enrolled1 = nullptr, * ph_course_enrolled2 = nullptr, * ph_course_enrolled3 = nullptr;
};
struct Node_class
{
	string name;
	Node_class* class_next = nullptr;
	Node_student* ph_student = nullptr;
};
struct Node_year
{
	int semestercount;
	string name;
	Node_year* year_next;
	Node_class* ph_classes = nullptr;
	Node_semester* ph_semester = nullptr;
};
struct Node_teacher
{
	string mail, fullname, date, cccd , pass;
	Node_teacher* teacher_next;
};
void updateScoreBoardOfACourse(Node_year* b);
void viewScoreBoardOfAClass(Node_class* a, Node_year* b);
void viewScoreBoardByStudent(Node_student* a, Node_year* b);
void viewScoreBoardOfACourse(Node_year* a);
void viewCourse_Student(Node_student* student_login, Node_year* current_year);
void export_studentIncourse_to_csv(Node_course* ph_course, Node_year* current_year);
// Các hàm thời gian
void print_current_time(int x, int y)
{
	time_t cur_time = time(0);
	char* dt = std::ctime(&cur_time);
	string time = dt;
	//meunu o trong 208, 60, o ngoai login la 140, 48
	print_fill_square(x, y, 27, 3, 15, time);
}
void check_time_for_semester(Node_year*& current_year)
{
	time_t cur_time = time(0);
	if (cur_time <= now + 10 * 60)
		current_year->semestercount = 1;
	else
		if (cur_time <= now + 20 * 60)
			current_year->semestercount = 2;
		else
			if (cur_time <= now + 30 * 60)
				current_year->semestercount = 3;

}
void print_semester_start_end_time(Node_year* current_year)
{

	time_t cur_time = time(0);
	if (cur_time <= now + 10 * 60)
	{

		if (cur_time <= now + 7 * 60)
		{
			time_t time = now + 7 * 60;
			char* dt = std::ctime(&time);
			string time_end = dt;
			print_fill_square(138, 60, 46, 3, 15, "Semester 1 ends at " + time_end);
		}
		else
		{
			time_t time = now + 10 * 60;
			char* dt = std::ctime(&time);
			string time_end = dt;
			print_fill_square(136, 60, 48, 3, 15, "Semester 2 starts at " + time_end);
		}


	}
	else
		if (cur_time <= now + 20 * 60)
		{
			if (cur_time <= now + 17 * 60)
			{
				time_t time = now + 17 * 60;
				char* dt = std::ctime(&time);
				string time_end = dt;
				print_fill_square(138, 60, 46, 3, 15, "Semester 2 ends at " + time_end);
			}
			else
			{
				time_t time = now + 20 * 60;
				char* dt = std::ctime(&time);
				string time_end = dt;
				print_fill_square(136, 60, 48, 3, 15, "Semester 3 starts at " + time_end);
			}
		}
		else
			if (cur_time <= now + 30 * 60)
			{
				if (cur_time <= now + 27 * 60)
				{
					time_t time = now + 27 * 60;
					char* dt = std::ctime(&time);
					string time_end = dt;
					print_fill_square(138, 60, 46, 3, 15, "Semester 3 ends at " + time_end);
				}
				else
				{
					time_t time = now + 30 * 60;
					char* dt = std::ctime(&time);
					string time_end = dt;
					print_fill_square(133, 60, 51, 3, 15, current_year->name + " will ends at " + time_end);
				}

			}
}
bool check_time_regis(Node_year*& current_year)
{
	return 1;
	check_time_for_semester(current_year);
	time_t cur_time = time(0);
	if (current_year->semestercount == 1)
		if (cur_time <= now + 7 * 60)
		{
			time_t time = now + 7 * 60;
			char* dt = std::ctime(&time);
			string time_end = dt;
			print_fill_square(160, 7, 74, 3, 15, "Registration session of semester 1 will end at " + time_end);
			return 1;
		}
		else { print_double_square(30, 10, 56, 3, 15, "Registration session of semester 1 has ran out of time"); return 0; }
	if (current_year->semestercount == 2)
		if (cur_time <= now + 17 * 60)
		{
			time_t time = now + 17 * 60;
			char* dt = std::ctime(&time);
			string time_end = dt;
			print_fill_square(160, 7, 74, 3, 15, "Registration session of semester 2 will end at " + time_end);
			return 1;
		}
		else { print_double_square(30, 10, 56, 3, 15, "Registration session of semester 2 has ran out of time"); return 0; }
	if (current_year->semestercount == 3)
		if (cur_time <= now + 27 * 60)
		{
			time_t time = now + 27 * 60;
			char* dt = std::ctime(&time);
			string time_end = dt;
			print_fill_square(160, 7, 74, 3, 15, "Registration session of semester 3 will end at " + time_end);
			return 1;
		}
		else { print_double_square(30, 10, 56, 3, 15, "Registration session of semester 3 has ran out of time"); return 0; }

}
bool check_year_end(Node_year*& current_year)
{
	return 1;
	time_t cur_time = time(0);
	if (cur_time <= now + 1800)
	{
		print_double_square(30, 10, 46, 3, 15, "The school year " + current_year->name + " has not ended yet!");
		return 0;
	}
	else return 1;
}
bool check_not_end_semester(Node_year*& current_year, bool view)
{
	return 1;
	check_time_for_semester(current_year);
	time_t cur_time = time(0);
	if (current_year->semestercount == 1)
		if (cur_time <= now + 7 * 60)
		{
			if(view) print_double_square(30, 10, 26, 3, 15, "Semester 1 has not ended");
			return 0;
		}
	if (current_year->semestercount == 2)
		if (cur_time <= now + 17 * 60)
		{
			if (view)print_double_square(30, 10, 26, 3, 15, "Semester 2 has not ended");
			return 0;
		}
	if (current_year->semestercount == 3)
		if (cur_time <= now + 27 * 60)
		{
			if (view) print_double_square(30, 10, 26, 3, 15, "Semester 3 has not ended");
			return 0;
		}
	return 1;
}
// Các hàm tìm node
Node_class* find_class_by_name(Node_class* ph_class, string class_name)
{
	Node_class* pc_class = ph_class;
	while (pc_class != NULL && pc_class->name != class_name)
		pc_class = pc_class->class_next;
	return pc_class;
}
Node_year* find_year(Node_year* ph_year, int year_no)
{
	if (ph_year == NULL)
		return NULL;
	Node_year* pc_year = ph_year;
	for (int i = 0; i < year_no - 1 && pc_year != NULL; i++, pc_year = pc_year->year_next);
	
		return pc_year;
}
Node_class* find_class(Node_class* ph_class, int class_no)
{
	if (ph_class == NULL)
		return NULL;
	Node_class* pc_class = ph_class;
	for (int i = 0; i < class_no - 1 && pc_class != NULL; i++, pc_class = pc_class->class_next);
	
		return pc_class;
}
Node_semester* find_semester(Node_semester* ph_semester, string semester_no_tmp)
{
	if (ph_semester == NULL)
		return NULL;
	semester_no_tmp = "Semester " + semester_no_tmp;
	Node_semester* pc_semester = ph_semester;
	while (pc_semester!=NULL && pc_semester->semester_no != semester_no_tmp)
		pc_semester = pc_semester->semester_next;

		return pc_semester;	
}
Node_course* find_course(Node_course* ph_course, int course_no)
{
	if (ph_course == NULL)
		return NULL;
	Node_course* pc_course = ph_course;
	for (int i = 0; i < course_no - 1 && pc_course != NULL; i++, pc_course = pc_course->course_next);

		return pc_course;
}
Node_course* find_course_byname(Node_course* ph_course, string course_name)
{
	if (ph_course == NULL)
		return NULL;
	Node_course* pc_course = ph_course;
	while (pc_course != NULL && pc_course->data.course_name != course_name)
		pc_course = pc_course->course_next;
		return pc_course;
}
Node_year* find_year_by_name(Node_year* ph_year, string year_name)
{
	if (ph_year == NULL)
		return NULL;
	Node_year* pc_year = ph_year;
	while (pc_year != NULL && pc_year->name != year_name)
		pc_year = pc_year->year_next;
	return pc_year;
}
Node_student* find_student_by_id(Node_student* ph_student, string id)
{
	Node_student* pc_student = ph_student;
	while (pc_student != NULL && pc_student->data.ID != id)
		pc_student = pc_student->student_next;
	return pc_student;
}
Node_student* find_node_student_for_login_account(long mssv, Node_year* ph_year)
{
	Node_student* student_choose = NULL;
	string year_name = "20" + to_string(mssv / 1000000) + "-" + "20" + to_string((mssv / 1000000) + 1);
	string chatluong[8] = { "NULL","NULL","NULL","NULL","NULL","APCS","VP","CLC" };
	string class_name = to_string(mssv / 1000000) + chatluong[(mssv / 1000) % 10];
	Node_year* year_choose = find_year_by_name(ph_year, year_name);
	if (year_choose == NULL)
		return NULL;
	else
	{
		Node_class* class_choose;
		int stt = 1;
		do
		{
			class_name = class_name + to_string(stt);
			class_choose = find_class_by_name(year_choose->ph_classes, class_name);
			if (class_choose != NULL)
				student_choose = find_student_by_id(class_choose->ph_student, to_string(mssv));
			else
				stt++;
			if (student_choose != NULL)
				break;
		} while (stt < 12);
		if (stt == 12)
			return NULL;
	}

	return student_choose;
}
Node_teacher* find_teacher_login(string mail, Node_teacher* ph_teacher)
{
	Node_teacher* pc_teacher = ph_teacher;
	while (pc_teacher != NULL && pc_teacher->mail != mail)
		pc_teacher = pc_teacher->teacher_next;
	return pc_teacher;
}
// Các hàm xóa các node
void deallocate_student(Node_student*& ph_student);
void deallocate_class(Node_class*& ph_class);
void deallocate_semester(Node_semester*& ph_semester);
void deallocate_course(Node_course*& ph_course);
void deallocate_student(Node_student*& ph_student)
{
	while (ph_student != NULL)
	{
		deallocate_course(ph_student->ph_course_enrolled1);
		deallocate_course(ph_student->ph_course_enrolled2);
		deallocate_course(ph_student->ph_course_enrolled3);
		Node_student* pc_student = ph_student->student_next;
		delete ph_student;
		ph_student = pc_student;
	}
}
void deallocate_class(Node_class*& ph_class)
{
	while (ph_class != NULL)
	{
		deallocate_student(ph_class->ph_student);
		Node_class* pc_class = ph_class->class_next;
		delete ph_class;
		ph_class = pc_class;
	}
}
void deallocate_semester(Node_semester*& ph_semester)
{
	while (ph_semester != NULL)
	{
		deallocate_course(ph_semester->ph_course);
		Node_semester* pc_semester= ph_semester->semester_next;
		delete ph_semester;
		ph_semester = pc_semester;
	}
}
void deallocate_course(Node_course*& ph_course)
{
	while (ph_course != NULL)
	{
		deallocate_student(ph_course->ph_student_enrolled);
		Node_course* pc_course = ph_course->course_next;
		delete ph_course;
		ph_course = pc_course;
	}
}
void deallocate_all_node(Node_year*& ph_year)
{
	while (ph_year != NULL)
	{
		deallocate_class(ph_year->ph_classes);
		deallocate_semester(ph_year->ph_semester);
		Node_year* pc_year = ph_year->year_next;
		delete ph_year;
		ph_year = pc_year;
	}
}
void delete_specific_class(Node_class*& ph_class, Node_class* pdel_class)
{
	deallocate_student(pdel_class->ph_student);
	if (ph_class == pdel_class)
	{
		ph_class = ph_class->class_next;
		delete pdel_class;
		return;
	}
	Node_class* pc_class = ph_class;
	while (pc_class->class_next != NULL && pc_class->class_next != pdel_class)
	{
		pc_class = pc_class->class_next;
	}
	pc_class->class_next = pc_class->class_next->class_next;
	delete pdel_class;
}
void delete_specific_student(Node_student*& ph_student, Node_student* pdel_student)
{
	if (ph_student == pdel_student)
	{
		ph_student = ph_student->student_next;
		delete pdel_student;
		return;
	}
	Node_student* pc_student = ph_student;
	while (pc_student->student_next != NULL && pc_student->student_next != pdel_student)
	{
		pc_student = pc_student->student_next;
	}
	pc_student->student_next = pc_student->student_next->student_next;
	delete pdel_student;
}
void delete_specific_course(Node_course*& ph_course, Node_course* pdel_course)
{
	if (ph_course == pdel_course)
	{
		ph_course = ph_course->course_next;
		delete pdel_course;
		return;
	}
	Node_course* pc_course = ph_course;
	while (pc_course->course_next != NULL && pc_course->course_next != pdel_course)
	{
		pc_course = pc_course->course_next;
	}
	pc_course->course_next = pc_course->course_next->course_next;
	delete pdel_course;
}
void delete_specific_course(Node_course*& ph_course, Node_course* pdel_course);
void delete_specific_student(Node_student*& ph_student, Node_student* pdel_student);
void deleteEnrolledCourse(Node_student*& student, Node_year*& current_year) {
	if (student->ph_course_enrolled1 == NULL && student->ph_course_enrolled2 == NULL && student->ph_course_enrolled3 == NULL)
	{
		print_double_square(30, 10, 37, 3, 15, "You have not enrolled in any course");
		return;
	}
	Node_course** ph_course_enrolled = nullptr;
	check_time_for_semester(current_year);
	if (current_year->semestercount == 1)
		ph_course_enrolled = &(student->ph_course_enrolled1);
	if (current_year->semestercount == 2)
		ph_course_enrolled = &(student->ph_course_enrolled2);
	if (current_year->semestercount == 3)
		ph_course_enrolled = &(student->ph_course_enrolled3);

	viewCourse_Student(student, current_year);
	print_type_in_box(30, 10, "Choose a course to delete", 5);
	char x1;
	cin >> x1;
	if (x1 > '9' || x1 < '1')
	{
		print_double_square(30, 15, 13, 3, 15, "Wrong input");
		return;
	}
	int x = x1 - 48;
	Node_course* course_choose = find_course(*ph_course_enrolled, x);
	string name_tmp = course_choose->data.course_name;
	if (course_choose != NULL)
	{
		delete_specific_course(*ph_course_enrolled, course_choose);
		print_double_square(30, 15, 34, 3, 15, "Delete enrolled course succeeded");
		Node_semester* semester_choose = nullptr;
		Node_course* course_choose_del = nullptr;
		if (current_year->semestercount == 1)
			semester_choose = find_semester(current_year->ph_semester, "1");
		if (current_year->semestercount == 2)
			semester_choose = find_semester(current_year->ph_semester, "2");
		if (current_year->semestercount == 3)
			semester_choose = find_semester(current_year->ph_semester, "3");
		course_choose_del = semester_choose->ph_course;

		while (course_choose_del != NULL && course_choose_del->data.course_name != name_tmp)
			course_choose_del = course_choose_del->course_next;

		Node_student* pc_student_enrolled = course_choose_del->ph_student_enrolled;
		while (pc_student_enrolled->data.ID != student->data.ID)
			pc_student_enrolled = pc_student_enrolled->student_next;

		delete_specific_student(course_choose_del->ph_student_enrolled, pc_student_enrolled);

	}
}
void reset_student(Node_year* ph_year)
{
	Node_year* pc_year = ph_year;
	while (pc_year != NULL)
	{
		Node_class* pc_class = pc_year->ph_classes;
		while (pc_class != NULL)
		{
			Node_student* pc_student = pc_class->ph_student;
			while (pc_student != NULL)
			{
				pc_student->ph_course_enrolled1 = NULL; pc_student->ph_course_enrolled2 = NULL; pc_student->ph_course_enrolled3 = NULL;
				pc_student = pc_student->student_next;
			}
			pc_class = pc_class->class_next;
		}
		pc_year = pc_year->year_next;
	}
}
// Các hàm in thông tin các node
void print_class(Node_class* ph_class)
{
	Node_class* pc_class = ph_class;
	int i = 1;
	gotoXY(118, 11);
	cout << "LIST OF CLASSES";
	while (pc_class != NULL)
	{
		gotoXY(121, 12 + i);
		cout << i++ << ":" << pc_class->name << endl;
		pc_class = pc_class->class_next;
	}
	print_double_square(116, 10, 19, i + 3, 15, "\0");
}
void print_year(Node_year* ph_year)
{
	Node_year* pc = ph_year;
	int i = 1;
	while (pc != NULL)
	{
		cout << i++ << ":" << pc->name << endl;
		pc = pc->year_next;
	}
}
void print_semester(Node_semester* ph_semester)
{
	Node_semester* pc = ph_semester;
	int i = 1;
	gotoXY(118, 11);
	cout << "LIST OF SEMESTERS";
	while (pc != NULL)
	{
		gotoXY(121, 12 + i);
		cout << i++ << ":" << pc->semester_no << endl;
		pc = pc->semester_next;
	}
	print_double_square(116, 10, 21, i + 3, 15, "\0");
}
void print_course(Node_course* ph_course)
{

	Node_course* pc = ph_course;
	int i = 1;
	gotoXY(119, 20);
	cout << "LIST OF COURSES";
	while (pc != NULL)
	{
		gotoXY(123, 21 + i);
		cout << i++ << ":" << pc->data.course_name << endl;
		pc = pc->course_next;
	}
	print_double_square(116, 19, 21, i + 3, 15, "\0");
}
void viewListofcourse(Node_course* ph_course)
{
	int i = 1;
	gotoXY(71, 20);
	cout << "Course ID  Course Name     Teacher Name     Number of Credits  The maximum number of students  Day of the week  The sessions";
	while (ph_course != NULL)
	{
		gotoXY(68, 20 + i);
		cout << i;
		gotoXY(71, 20 + i++);
		cout << ph_course->data.id;
		for (int i = 0; i < 14 - ph_course->data.id.length(); i++) cout << " ";
		cout << ph_course->data.course_name;
		for (int i = 0; i < 13 - ph_course->data.course_name.length(); i++) cout << " ";
		cout << ph_course->data.teacher_name;
		for (int i = 0; i < 25 - ph_course->data.teacher_name.length(); i++) cout << " ";
		cout << ph_course->data.number_of_credits;
		for (int i = 0; i < 23; i++) cout << " ";
		cout << ph_course->data.max_num_student;
		for (int i = 0; i < 23; i++) cout << " ";
		cout << ph_course->data.days_of_week;
		for (int i = 0; i < 9; i++) cout << " ";
		cout << ph_course->data.session1 << " ";
		cout << ph_course->data.session2;

		ph_course = ph_course->course_next;
	}
	print_double_square(69, 20, 128, i, 15, "\0");
	print_double_square(67, 20, 3, i, 15, "\0");

	return;
}
void viewCourse_Student(Node_student* student_login, Node_year* current_year)
{
	if (student_login->ph_course_enrolled1 == NULL && student_login->ph_course_enrolled2 == NULL && student_login->ph_course_enrolled3 == NULL)
	{
		print_double_square(30, 10, 30, 3, 15, "Haven't enrolled any course!");
		return;
	}
	check_time_for_semester(current_year);
	Node_course* ph_enrolled_course = nullptr;
	if (current_year->semestercount == 1)
		ph_enrolled_course = student_login->ph_course_enrolled1;
	if (current_year->semestercount == 2)
		ph_enrolled_course = student_login->ph_course_enrolled2;
	if (current_year->semestercount == 3)
		ph_enrolled_course = student_login->ph_course_enrolled3;

	viewListofcourse(ph_enrolled_course);

}
void viewAllClass(Node_year* year) {
	int i = 1;
	gotoXY(119, 10);
	cout << "LIST OF CLASSES";
	int count = 1;
	while (year) {
		Node_class* pc_class = year->ph_classes;
		int dem = 1;
		while (pc_class) {
			if (pc_class == year->ph_classes)
			{
				gotoXY(122, 11 + i++);
				cout << count++ << "/" << year->name;
			}
			gotoXY(122, 11 + i++);
			cout << dem++ << "." << pc_class->name << endl;
			pc_class = pc_class->class_next;
		}
		year = year->year_next;
	}
	print_double_square(117, 10, 19, i + 1, 15, "\0");
	return;
}
void viewAllStudentInAClass(Node_student* ph_student) {
	int i = 1;
	gotoXY(78, 40);
	cout << "No       ID             First Name       Last Name       Gender       Date of birth       Social ID";
	Node_student* pc_student = ph_student;
	while (pc_student) {
		gotoXY(78, 40 + i++);
		cout << pc_student->data.No << "        ";
		cout << pc_student->data.ID << "       ";
		cout << pc_student->data.first_name;
		for (int i = 0; i < 19 - pc_student->data.first_name.length(); i++)
			cout << " ";
		cout << pc_student->data.lastname;
		for (int i = 0; i < 16 - pc_student->data.lastname.length(); i++)
			cout << " ";
		cout << pc_student->data.gender << "  ";
		for (int i = 0; i < 10 - pc_student->data.gender.length(); i++)
			cout << " ";
		cout << pc_student->data.date << "       ";
		cout << pc_student->data.social_ID << "   ";

		pc_student = pc_student->student_next;
	}
	print_double_square(76, 40, 104, i, 15, "\0");
	return;
}
void viewListofstudentsincourse(Node_student* ph_student)
{
	int i = 1;
	gotoXY(78, 30);
	cout << "No       ID             First Name       Last Name       Gender       Date of birth       Social ID";
	Node_student* pc_student = ph_student;
	while (pc_student) {
		gotoXY(78, 30 + i++);
		cout << pc_student->data.No << "        ";
		cout << pc_student->data.ID << "       ";
		cout << pc_student->data.first_name;
		for (int i = 0; i < 19 - pc_student->data.first_name.length(); i++)
			cout << " ";
		cout << pc_student->data.lastname;
		for (int i = 0; i < 16 - pc_student->data.lastname.length(); i++)
			cout << " ";
		cout << pc_student->data.gender << "  ";
		for (int i = 0; i < 10 - pc_student->data.gender.length(); i++)
			cout << " ";
		cout << pc_student->data.date << "       ";
		cout << pc_student->data.social_ID << "   ";

		pc_student = pc_student->student_next;
	}
	print_double_square(76, 30, 104, i, 15, "\0");
	return;
}
//View profile
void view_profile_teacher(Node_teacher* teacher_login)
{
	int i = 1;//30 24 30
	gotoXY(86, 20);
	cout << "Gmail                         FullName                Date of birth     ID";
	//       21127512     Nguyen Le Hoang  Kha       08/02/2003      123456789123
	gotoXY(86, 20 + i++);
	cout << teacher_login->mail;
	for (int i = 0; i < 30 - teacher_login->mail.length(); i++) cout << " ";
	cout << teacher_login->fullname;
	for (int i = 0; i < 26 - teacher_login->fullname.length(); i++) cout << " ";
	cout << teacher_login->date << "      ";
	cout << teacher_login->cccd;
	print_double_square(84, 20, 88, i, 15, "\0");
}
void view_profile_student(Node_student* student_login)
{
	int i = 1;
	gotoXY(78, 20);
	cout << "No       ID             First Name       Last Name       Gender       Date of birth       Social ID";
		gotoXY(78, 20 + i++);
		cout << student_login->data.No << "        ";
		cout << student_login->data.ID << "       ";
		cout << student_login->data.first_name;
		for (int i = 0; i < 19 - student_login->data.first_name.length(); i++)
			cout << " ";
		cout << student_login->data.lastname;
		for (int i = 0; i < 16 - student_login->data.lastname.length(); i++)
			cout << " ";
		cout << student_login->data.gender << "  ";
		for (int i = 0; i < 10 - student_login->data.gender.length(); i++)
			cout << " ";
		cout << student_login->data.date << "       ";
		cout << student_login->data.social_ID << "   ";

	print_double_square(76, 20, 104, i , 15, "\0");
	return;
}
//Scoreboard
void export_studentIncourse_to_csv(Node_course* ph_course, Node_year* current_year)
{
	if (ph_course == NULL) return;
	int count = 1;
	Node_course* pc_course = ph_course;
	fstream write("CoursesData\\Semester " + to_string(current_year->semestercount) + "\\Courses.txt", ios::out);
	while (pc_course != NULL)
	{
		string course_name = pc_course->data.course_name;
		if (pc_course->ph_student_enrolled != NULL)
		{
			write << course_name;
			//check xem có cần xuống dòng không
			Node_course* temp = pc_course->course_next;
			while (temp != NULL)
			{
				if (temp->ph_student_enrolled != NULL)
				{
					write << endl; break;
				}
				temp = temp->course_next;
			}
			ofstream write1("CoursesData\\Semester " + to_string(current_year->semestercount) + "\\" + course_name + ".csv", ios::out);
			Node_student* pc_student = pc_course->ph_student_enrolled;
			while (pc_student != NULL)
			{
				write1 << count++ << "," << pc_student->data.ID << "," << pc_student->data.first_name << "," << pc_student->data.lastname;
				pc_student = pc_student->student_next;
				if (pc_student) write1 << endl;
			}
			write1.close();
		}
		pc_course = pc_course->course_next;
	}

	write.close();
}
void updateStudentResult(Node_student*& a, Node_year* b, string s, double x, double y, double z, double t) {
	//use while loop to get each  student ID then use the find_student by id to make changes
	check_time_for_semester(b);
	if (b->semestercount == 1) {
		Node_course* cur = a->ph_course_enrolled1;
		while (cur->data.course_name != s) {
			cur = cur->course_next;
		}
		cur->total = x;
		cur->final = y;
		cur->midterm = z;
		cur->other = t;
	}
	if (b->semestercount == 2) {
		Node_course* cur = a->ph_course_enrolled2;
		while (cur->data.course_name != s) {
			cur = cur->course_next;
		}
		cur->total = x;
		cur->final = y;
		cur->midterm = z;
		cur->other = t;
	}
	if (b->semestercount == 3) {
		Node_course* cur = a->ph_course_enrolled3;
		while (cur->data.course_name != s) {
			cur = cur->course_next;
		}
		cur->total = x;
		cur->final = y;
		cur->midterm = z;
		cur->other = t;
	}
}
void viewScoreBoardOfACourse(Node_year* a) {
	check_time_for_semester(a);
	fstream fs;
	fs.open("CoursesData\\Semester " + to_string(a->semestercount) + "\\Courses.txt");
	int i = 1;
	gotoXY(119, 11);
	cout << "LIST OF COURSES";
	while (!fs.eof()) {
		gotoXY(123, 12 + i);
		string s;
		fs >> s;
		cout << i++ << ":" << s << endl;
	}
	print_double_square(116, 10, 21, i + 3, 15, "\0");
	print_type_in_box(30, 25, "Choose a course", 5);
	char no1; cin >> no1;
	if (no1 > '9' || no1 < '1')
	{
		print_double_square(30, 25, 13, 3, 15, "Wrong input");
		return;
	}
	int no = no1 - 48;
	fstream fs2;
	fs2.open("CoursesData\\Semester " + to_string(a->semestercount) + "\\Courses.txt");
	string s;
	while (no-- != 0)
		fs2 >> s;

	int i1 = 1;
	int i2 = i;
	fstream fs1;
	fs1.open("CoursesData\\Semester " + to_string(a->semestercount) + "\\" + s + ".csv");
	gotoXY(74, 15 + i);
	cout << "No     Student ID          FullName          Total Mark         Final Mark      Midterm Mark      Other Mark";
	while (!fs1.eof()) {
		string no, id, first_name, last_name, a, b, c, d;
		getline(fs1, no, ',');
		getline(fs1, id, ',');
		getline(fs1, first_name, ',');
		getline(fs1, last_name, ',');
		getline(fs1, a, ',');
		getline(fs1, b, ',');
		getline(fs1, c, ',');
		getline(fs1, d);
		gotoXY(74, 16 + i++);
		i1++;
		cout << no << "       ";
		cout << id << "       ";
		cout << first_name << " ";
		cout << last_name;
		for (int i = 0; i < 25 - (first_name.length() + last_name.length()); i++) cout << " ";
		cout << a; for (int i = 0; i < 19 - a.length(); i++) cout << " ";
		cout << b; for (int i = 0; i < 17 - b.length(); i++) cout << " ";
		cout << c; for (int i = 0; i < 17 - c.length(); i++) cout << " ";
		cout << d;
	}
	print_double_square(72, 15 + i2, 112, i1, 15, "\0");
	fs1.close();
	fs.close();
} //view scoreboard
void viewScoreBoardByStudent(Node_student* a, Node_year* b) {
	// use find_node_student_for_login_account function to Node student a
	Node_course* view = nullptr;
	check_time_for_semester(b);
	if (b->semestercount == 1)
		view = a->ph_course_enrolled1;
	if (b->semestercount == 2)
		view = a->ph_course_enrolled2;
	if (b->semestercount == 3)
		view = a->ph_course_enrolled3;

	print_course(view);
	print_type_in_box(30, 10, "Choose a course", 5);
	char no1; cin >> no1;
	if (no1 > '9' || no1 < '1')
	{
		print_double_square(30, 15, 13, 3, 15, "Wrong input");
		return;
	}
	int no = no1 - 48;
	view = find_course(view, no);

	gotoXY(80, 32);
	cout << "Student ID          Fullname          Total Mark       Final Mark       Midterm Mark       Other Mark";
	gotoXY(81, 33);
	cout << a->data.ID;
	for (int i = 0; i < 6; i++) cout << " ";
	cout << a->data.first_name << " ";
	cout << a->data.lastname;
	for (int i = 0; i < 27 - (a->data.first_name.length() + a->data.lastname.length()); i++) cout << " ";
	cout << view->total << "               ";
	cout << view->final << "                 ";
	cout << view->midterm << "                  ";
	cout << view->other;
	print_double_square(79, 32, 103, 2, 15, "\0");

}
void viewScoreBoardOfAClass(Node_class* a, Node_year* b) {
	Node_student* curStudent = a->ph_student;
	Node_course* curEnrolled = nullptr;
	double totalGPA = 0;
	int countStudent = 0;
	check_time_for_semester(b);
	int i = 1;
	gotoXY(80, 32);
	cout << "Student ID          Fullname          Course Name         Final Mark      GPA      Total GPA of class";

	while (curStudent) {
		if (b->semestercount == 1)
			curEnrolled = curStudent->ph_course_enrolled1;
		if (b->semestercount == 2)
			curEnrolled = curStudent->ph_course_enrolled2;
		if (b->semestercount == 3)
			curEnrolled = curStudent->ph_course_enrolled3;
		if (curEnrolled != nullptr)
			countStudent += 1;
		double gpacourse = 0;
		int cnt = 0;
		Node_course* tmp = curEnrolled;
		while (curEnrolled) {
			gotoXY(81, 32 + i++);
			cout << curStudent->data.ID;
			for (int i = 0; i < 6; i++) cout << " ";
			cout << curStudent->data.first_name << " ";
			cout << curStudent->data.lastname;
			cnt += 1;
			gpacourse += curEnrolled->final;
			for (int i = 0; i < 26 - (curStudent->data.first_name.length() + curStudent->data.lastname.length()); i++) cout << " ";
			cout << curEnrolled->data.course_name << "                 ";
			cout << curEnrolled->final << "           ";
			curEnrolled = curEnrolled->course_next;
		}
		if (tmp != NULL)
		{
			cout << (double)gpacourse / cnt;
			totalGPA += gpacourse;
		}

		curStudent = curStudent->student_next;
	}
	gotoXY(172, 32 + i);
	cout << (double)totalGPA / countStudent;
	print_double_square(79, 32, 103, i + 1, 15, "\0");

}
void updateScoreBoardOfACourse(Node_year* b) {
	check_time_for_semester(b);
	fstream fs;
	fs.open("CoursesData\\Semester " + to_string(b->semestercount) + "\\Courses.txt");
	while (!fs.eof()) {
		string s;
		fs >> s;
		fstream fs1;
		fs1.open("CoursesData\\Semester " + to_string(b->semestercount) + "\\" + s + ".csv");
		if (fs1.is_open()) {
			while (!fs1.eof()) {
				long mssv;
				double x, y, z, t;
				string ign1, ign2;
				fs1.ignore();
				fs1.ignore();
				fs1 >> mssv;
				Node_student* curStudent = find_node_student_for_login_account(mssv, b);
				if (curStudent == nullptr) break;
				fs1.ignore();
				getline(fs1, ign1, ',');
				getline(fs1, ign2, ',');
				fs1 >> x;
				fs1.ignore();
				fs1 >> y;
				fs1.ignore();
				fs1 >> z;
				fs1.ignore();
				fs1 >> t;
				fs1.ignore();
				updateStudentResult(curStudent, b, s, x, y, z, t);
			}
		}
		fs1.close();
	}
	fs.close();
	print_double_square(30, 10, 30, 3, 15, "Update scoreboard completed!");
}
//Enroll course
void add_enrolled_course(Node_course*& ph_course_enrolled, Node_course* enrolled_course)
{
	Node_course* tmp = new Node_course;
	tmp->data = enrolled_course->data;
	tmp->course_next = NULL;
	tmp->ph_student_enrolled = NULL;
	if (ph_course_enrolled == NULL)
	{
		ph_course_enrolled = tmp;
	}
	else
	{
		Node_course* pc_enrolled_course = ph_course_enrolled;
		while (pc_enrolled_course->course_next != NULL)
			pc_enrolled_course = pc_enrolled_course->course_next;
		pc_enrolled_course->course_next = tmp;
	}
}
void add_enrolled_student(Node_student*& ph_student_enrolled, Node_student* enrolled_student)
{
	Node_student* tmp = new Node_student;
	tmp->data = enrolled_student->data;
	tmp->student_next = NULL;
	tmp->ph_course_enrolled1 = NULL;
	tmp->ph_course_enrolled2 = NULL;
	tmp->ph_course_enrolled3 = NULL;
	if (ph_student_enrolled == NULL)
	{
		ph_student_enrolled = tmp;
	}
	else
	{
		Node_student* pc_enrolled_student = ph_student_enrolled;
		while (pc_enrolled_student->student_next != NULL)
			pc_enrolled_student = pc_enrolled_student->student_next;
		pc_enrolled_student->student_next = tmp;
	}
	Node_student* pc_enrolled_student = ph_student_enrolled;

}
bool check_course_sessions(Node_course* course_enrolled, Node_course* ph_course_enrolled)
{
	if (ph_course_enrolled == NULL)
		return true;
	Node_course* pc_course_enrolled = ph_course_enrolled;
	while (pc_course_enrolled != NULL)
	{
		if (pc_course_enrolled->data.session1 == course_enrolled->data.session1 || pc_course_enrolled->data.session1 == course_enrolled->data.session2 || pc_course_enrolled->data.session2 == course_enrolled->data.session1 || pc_course_enrolled->data.session2 == course_enrolled->data.session2)
			return false;
		pc_course_enrolled = pc_course_enrolled->course_next;
	}
	return true;
}
bool check_not_over_5_enrolled_course(Node_course* ph_enrolled_course)
{
	int dem = 0;
	while (ph_enrolled_course != NULL)
	{
		ph_enrolled_course = ph_enrolled_course->course_next;
		dem++;
	}
	if (dem < 5)
		return true;
	else return false;
}
bool check_not_over_max_student_in_a_course(Node_student* ph_student_enrolled, int max)
{
	int dem = 0;
	while (ph_student_enrolled != NULL)
	{
		++dem;
		ph_student_enrolled = ph_student_enrolled->student_next;
	}
	if (dem < max)
		return true;
	else return false;
}
void enroll_course(Node_student* student_login, Node_year*& current_year)
{
	char no_course1;
	Node_semester* semester_choose = nullptr;
	Node_course** ph_course_enrolled = nullptr;
	check_time_for_semester(current_year);
	cout << current_year->semestercount;
	if (current_year->semestercount == 1)
	{
		ph_course_enrolled = &student_login->ph_course_enrolled1;
		semester_choose = find_semester(current_year->ph_semester, to_string(1));
	}
	if (current_year->semestercount == 2)
	{
		ph_course_enrolled = &student_login->ph_course_enrolled2;
		semester_choose = find_semester(current_year->ph_semester, to_string(2));
	}
	if (current_year->semestercount == 3)
	{
		ph_course_enrolled = &student_login->ph_course_enrolled3;
		semester_choose = find_semester(current_year->ph_semester, to_string(3));
	}
	if (semester_choose->ph_course != NULL)
	{
		if (check_time_regis(current_year))
			if (check_not_over_5_enrolled_course(*ph_course_enrolled))
			{
				print_double_square(120, 15, 12, 3, 15, "Semester " + to_string(current_year->semestercount));
				viewListofcourse(semester_choose->ph_course);
				print_type_in_box(30, 10, "Choose a course", 5);
				cin >> no_course1;
				if (no_course1 > '9' || no_course1 < '1')
				{
					print_double_square(30, 15, 13, 3, 15, "Wrong input");
					return;
				}
				int no_course = no_course1 - 48;
				Node_course* course_choose = find_course(semester_choose->ph_course, no_course);
				if (check_not_over_max_student_in_a_course(course_choose->ph_student_enrolled, course_choose->data.max_num_student))
					if (check_course_sessions(course_choose, *ph_course_enrolled))// check xem có bị trùng giờ học không?
					{
						print_double_square(30, 15, 22, 3, 15, "Enrolling succeeded!");
						add_enrolled_course(*ph_course_enrolled, course_choose);
						add_enrolled_student(course_choose->ph_student_enrolled, student_login);
					}
					else print_double_square(30, 15, 79, 3, 15, "Your chosen course has conflicting sessions with your other enrolled courses!");
				else print_double_square(30, 15, 39, 3, 15, "Course reaches limitation of students");
			}
			else
			{
				print_double_square(30, 10, 42, 3, 15, "You can not enrolled more than 5 courses");
			}
	} else print_double_square(30, 10, 39, 3, 15, "Semester "+ to_string(current_year->semestercount) + " has not been added courses");
	
}
bool check_year_name_appropriate(string year_name)
{
	int former = year_name[0] + year_name[1] + year_name[2] + year_name[3];
	int later = year_name[5] + year_name[6] + year_name[7] + year_name[8];
	if (year_name.length() == 9 && (later - former) == 1 && year_name[4] == '-')
		return 1;
	else return 0;
}
bool check_year_duplicate(Node_year* ph_year, string year_name)
{
	if (ph_year == NULL) return 1;
	while (ph_year != NULL)
	{
		if (ph_year->name == year_name)
			return 0;
		ph_year = ph_year->year_next;
	}
	return 1;
}
bool check_class_duplicate(Node_class* ph_class, string class_name)
{
	if (ph_class == NULL) return 1;
	while (ph_class != NULL)
	{
		if (ph_class->name == class_name)
			return 0;
		ph_class = ph_class->class_next;
	}
	return 1;
}
bool check_course_duplicate(Node_course* ph_course, string course_name)
{
	if (ph_course == NULL) return 1;
	while (ph_course != NULL)
	{
		if (ph_course->data.course_name == course_name)
			return 0;
		ph_course = ph_course->course_next;
	}
	return 1;
}
//Add các Node cơ bản
void add_1st_student(Node_student*& ph_student, string class_name, string year_name)
{
	year_name = to_string(year_name[2] - 48) + to_string(year_name[3] - 48);
	ifstream read("StudentData\\" + year_name + "\\" + class_name + ".csv");
	if (!read.is_open())
	{
		print_double_square(30, 15, 28, 3, 15, "This class does not exists");
		return;
	}
	Node_student* pc_student = ph_student;
	if (pc_student != NULL)
	{
		print_double_square(30, 15, 39, 3, 15, "Student have been added to this class");
		return;
	}
	while (!read.eof())
	{
		Node_student* tmp = new Node_student;
		getline(read, tmp->data.No, ',');
		getline(read, tmp->data.ID, ',');
		getline(read, tmp->data.first_name, ',');
		getline(read, tmp->data.lastname, ',');
		getline(read, tmp->data.gender, ',');
		getline(read, tmp->data.date, ',');
		getline(read, tmp->data.social_ID, ',');
		getline(read, tmp->data.password);
		tmp->student_next = NULL;
		tmp->ph_course_enrolled1 = NULL;
		tmp->ph_course_enrolled2 = NULL;
		tmp->ph_course_enrolled3 = NULL;
		if (pc_student == NULL)
		{
			ph_student = tmp;
			pc_student = tmp;
		}
		else
		{
			pc_student->student_next = tmp;
			pc_student = pc_student->student_next;
		}

	}
	read.close();
	viewAllStudentInAClass(ph_student);
}
void add_semester(Node_semester*& ph_semester)
{
	int no = 1;
	for (int i = 0; i < 3; i++)
	{
		string semester_no_tmp = "Semester " + to_string(no++);
		Node_semester* tmp = new Node_semester;
		tmp->semester_no = semester_no_tmp;
		tmp->ph_course = NULL;
		tmp->semester_next = NULL;
		/*tmp->start_date = now;
		tmp->regis_start = now;
		tmp->regis_end = now + 60;
		tmp->end_date = now + 120;
		now += 120;*/
		if (ph_semester == NULL)
		{
			ph_semester = tmp;
		}
		else
		{
			Node_semester* pc_semester = ph_semester;
			while (pc_semester->semester_next != NULL)
				pc_semester = pc_semester->semester_next;
			pc_semester->semester_next = tmp;
		}
	}

}
void add_course(Node_course*& ph_course, string semester_no, string year_name, bool view)
{
	if (ph_course == nullptr)
	{
		year_name = to_string(year_name[2] - 48) + to_string(year_name[3] - 48);
		fstream read("StudentData\\" + year_name + "\\" + semester_no + ".txt", ios::in);

		while (!read.eof())
		{
			COURSE_DATA DATA;
			read >> DATA.id; read.ignore();
			getline(read, DATA.course_name);
			getline(read, DATA.teacher_name);
			read >> DATA.number_of_credits;
			read >> DATA.max_num_student;
			read >> DATA.days_of_week;
			read >> DATA.session1;
			read >> DATA.session2;
			Node_course* tmp = new Node_course;
			tmp->data = DATA;
			tmp->course_next = NULL;
			tmp->ph_student_enrolled = NULL;
			Node_course* pc_course = ph_course;
			if (pc_course == NULL)
			{
				ph_course = tmp;
			}
			else
			{
				while (pc_course->course_next != NULL)
					pc_course = pc_course->course_next;
				pc_course->course_next = tmp;
			}
		}
		read.close();
		if(view) viewListofcourse(ph_course);
	}
	else
	{
		COURSE_DATA DATA;
		print_double_square(139, 10, 87, 14, 15, "\0");
		int y = 10;
		gotoXY(140, y++);
		cout << "Course ID: "; cin >> DATA.id; cin.ignore();
		gotoXY(140, y++);
		cout << "Course Name: "; getline(cin, DATA.course_name);
		gotoXY(140, y++);
		cout << "Teacher Name: "; getline(cin, DATA.teacher_name);
		gotoXY(140, y++);
		cout << "Number of Credits: "; cin >> DATA.number_of_credits;
		gotoXY(140, y++);
		cout << "The maximum number of students in the course(default 50): "; cin >> DATA.max_num_student;
		gotoXY(140, y++);
		cout << "Day of the week: "; cin >> DATA.days_of_week;
		gotoXY(140, y++);
		cout << "          MON / TUE / WED / THU / FRI / SAT\n";
		gotoXY(140, y++);
		cout << "S1(07:30)";
		gotoXY(140, y++);
		cout << "S2(09:30)";
		gotoXY(140, y++);
		cout << "S3(13:30)";
		gotoXY(140, y++);
		cout << "S4(15:30)";
		gotoXY(140, y++);
		cout << "The session that the course will be performed(Choose 2 session in a week)(Ex: MON_S2)";
		gotoXY(140, y++);
		cout << "Session 1: ";
		cin >> DATA.session1;

		do
		{
			gotoXY(140, y);
			cout << "Session 2: "; cin >> DATA.session2;
		} while (DATA.session1 == DATA.session2);
		if (check_course_duplicate(ph_course, DATA.course_name))
		{
			Node_course* tmp = new Node_course;
			tmp->data = DATA;
			tmp->course_next = NULL;
			tmp->ph_student_enrolled = NULL;
			Node_course* pc_course = ph_course;
			while (pc_course->course_next != NULL)
				pc_course = pc_course->course_next;
			pc_course->course_next = tmp;
		}
		else print_double_square(30, 15, 15, 3, 15, "Not accepted!");
	}
}
void add_class(Node_class*& ph_class, string class_name)
{
	Node_class* tmp = new Node_class;
	tmp->name = class_name;
	tmp->class_next = NULL;
	tmp->ph_student = NULL;
	if (ph_class == NULL)
	{
		ph_class = tmp;
	}
	else
	{
		Node_class* pc_class = ph_class;
		while (pc_class->class_next != NULL)
			pc_class = pc_class->class_next;
		pc_class->class_next = tmp;
	}
}
void add_year(Node_year*& ph_year, string year_name, Node_year*& current_year)
{
	now = time(0);
	Node_year* tmp = new Node_year;
	tmp->name = year_name;
	tmp->ph_classes = NULL;
	tmp->ph_semester = NULL;
	tmp->year_next = NULL;
	current_year = tmp;
	if (ph_year == NULL)
	{
		ph_year = tmp;
	}
	else
	{
		Node_year* pc = ph_year;
		while (pc->year_next != NULL)
			pc = pc->year_next;
		pc->year_next = tmp;
	}
}
void add_teacher(Node_teacher*& ph_teacher)
{
	ifstream read("GiaoVu.csv");
	Node_teacher* pc_teacher = ph_teacher;
	if (ph_teacher != NULL)
	{
		return;
	}
	while (!read.eof())
	{
		Node_teacher* tmp = new Node_teacher;
		getline(read, tmp->mail, ',');
		getline(read, tmp->fullname, ',');
		getline(read, tmp->date, ',');
		getline(read, tmp->cccd, ',');
		getline(read, tmp->pass);
		tmp->teacher_next = NULL;
		if (pc_teacher == NULL)
		{
			ph_teacher = tmp;
			pc_teacher = tmp;
		}
		else
		{
			pc_teacher->teacher_next = tmp;
			pc_teacher = pc_teacher->teacher_next;
		}

	}
	read.close();
}
//Save load
void save_enrolling_data(Node_course* ph_course, Node_year* current_year)
{
	if (ph_course == NULL) return;
	int count = 1;
	Node_course* pc_course = ph_course;
	fstream write("SaveCoursesData\\Semester " + to_string(current_year->semestercount) + "\\Courses.txt", ios::out);
	while (pc_course != NULL)
	{
		string course_name = pc_course->data.course_name;
		if (pc_course->ph_student_enrolled != NULL)
		{
			write << course_name;
			//check xem có cần xuống dòng không
			Node_course* temp = pc_course->course_next;
			while (temp != NULL)
			{
				if (temp->ph_student_enrolled != NULL)
				{
					write << endl; break;
				}
				temp = temp->course_next;
			}
			ofstream write1("SaveCoursesData\\Semester " + to_string(current_year->semestercount) + "\\" + course_name + ".csv", ios::out);
			Node_student* pc_student = pc_course->ph_student_enrolled;
			while (pc_student != NULL)
			{
				write1 << count++ << "," << pc_student->data.ID << "," << pc_student->data.first_name << "," << pc_student->data.lastname;
				pc_student = pc_student->student_next;
				if (pc_student) write1 << endl;
			}
			write1.close();
		}
		pc_course = pc_course->course_next;
	}

	write.close();
}
void savePassword(Node_year* a) {
	fstream fs;
	Node_year* d = a;
	while (a) {
		Node_class* b = a->ph_classes;
		while (b) {
			fs.open((string)"StudentData\\" + (a->name)[2] + (a->name)[3] + "\\" + b->name + ".csv");
			Node_student* c = b->ph_student;
			while (c) {
				fs << c->data.No << "," << c->data.ID << "," << c->data.first_name << "," << c->data.lastname << "," << c->data.gender << "," << c->data.date << "," << c->data.social_ID << "," << c->data.password;
				c = c->student_next;
				if (c) {
					fs << endl;
				}
			}
			fs.close();
			b = b->class_next;
		}
		a = a->year_next;
	}

}
void saveStudentData(Node_year* ph_year, Node_year* current_year)
{
	if (ph_year != NULL)
	{
		//Save time
		ofstream time("StudentData\\Save\\time.txt");
		time << now;
		time.close();
		//Save bool update
		ofstream update1("StudentData\\Save\\update.txt");
		update1 << update;
		update1.close();
		fstream fyear("StudentData\\Save\\CreatedYear.txt", ios::out);
		while (ph_year != NULL)
		{
			fyear << ph_year->name;
			if (ph_year->ph_classes != NULL)
			{
				ofstream fclass("StudentData\\" + ph_year->name.substr(2, 2) + "\\Save\\CreatedClass.txt");
				Node_class* pc_class = ph_year->ph_classes;
				while (pc_class != NULL)
				{
					fclass << pc_class->name;
					if (pc_class->ph_student != nullptr)
						ofstream student("StudentData\\" + ph_year->name.substr(2, 2) + "\\Save\\" + pc_class->name + "_studentadded.txt");
					pc_class = pc_class->class_next;
					if (pc_class != NULL)
						fclass << endl;
				}
			}

			if (current_year->ph_semester != NULL)
			{
				ofstream semester_created("StudentData\\" + current_year->name.substr(2, 2) + "\\Save\\SemesterCreated.txt");
				semester_created.close();
				Node_semester* pc_semester = current_year->ph_semester;
				while (pc_semester != nullptr)
				{
					if (pc_semester->ph_course != NULL)
						ofstream fcourse("StudentData\\" + current_year->name.substr(2, 2) + "\\Save\\" + pc_semester->semester_no + "_courseadded.txt");
					pc_semester = pc_semester->semester_next;
				}
			}
			ph_year = ph_year->year_next;
			if (ph_year != NULL)
				fyear << endl;
		}
		fyear.close();
	}
	//Save enrolling data
	if (update == 0)
	{
		if (current_year->ph_semester != NULL)
		{
			Node_semester* semester_choose = nullptr;
			if (current_year->semestercount == 1)
				semester_choose = find_semester(current_year->ph_semester, "1");
			if (current_year->semestercount == 2)
				semester_choose = find_semester(current_year->ph_semester, "2");
			if (current_year->semestercount == 3)
				semester_choose = find_semester(current_year->ph_semester, "3");
			if (semester_choose->ph_course != NULL)
				save_enrolling_data(semester_choose->ph_course, current_year);
		}
	}
}
void loadFile(Node_year*& ph_y, Node_year *& current_year) {
	fstream fi;
	Node_year* yCur = ph_y;
	fi.open("StudentData\\Save\\CreatedYear.txt", ios::in);
	if (!fi.is_open())
		return;
	//Load cac node
	while (!fi.eof()) {
		if (!ph_y) {
			ph_y = new Node_year;
			fi >> ph_y->name;
			yCur = ph_y;
			//fstream check_semester("StudentData\\" + yCur->name.substr(2, 2) + "\\Save\\CreatedSemester");
			yCur->year_next = nullptr;
			current_year = yCur;
		}
		else {
			yCur->year_next = new Node_year;
			fi >> yCur->year_next->name;
			yCur = yCur->year_next;
			current_year = yCur;
			yCur->year_next = 0;
		}
	}
	fi.close();

	yCur = ph_y;
	Node_class* cCur = 0;
	fstream fiClass;
	while (yCur) {
		fiClass.open("StudentData\\" + yCur->name.substr(2, 2) + "\\Save\\CreatedClass.txt", ios::in);
		while (!fiClass.eof()) {
			if (!yCur->ph_classes) {
				yCur->ph_classes = new Node_class;
				fiClass >> yCur->ph_classes->name;
				//cout << yCur->ph_classes->name;
				cCur = yCur->ph_classes;
				yCur->ph_classes->class_next = 0;
			}
			else {
				cCur->class_next = new Node_class;
				fiClass >> cCur->class_next->name;
				//cout << cCur->name;
				cCur = cCur->class_next;
				cCur->class_next = 0;
			}
		}
		yCur = yCur->year_next;
		fiClass.close();
	}
	fstream fiStudent;
	yCur = ph_y;
	//load hoc sinh
	Node_student* sCur = NULL;
	while (yCur) {
		cCur = yCur->ph_classes;
		while (cCur) {
			fstream check_added("StudentData\\" + yCur->name.substr(2, 2) + "\\Save\\" + cCur->name + "_studentadded.txt");
			if (check_added.is_open())
			{
				fiStudent.open("StudentData\\" + yCur->name.substr(2, 2) + "\\" + cCur->name + ".csv", ios::in);
				while (!fiStudent.eof()) {
					if (!cCur->ph_student) {
						cCur->ph_student = new Node_student;
						getline(fiStudent, cCur->ph_student->data.No, ',');
						getline(fiStudent, cCur->ph_student->data.ID, ',');
						getline(fiStudent, cCur->ph_student->data.first_name, ',');
						getline(fiStudent, cCur->ph_student->data.lastname, ',');
						getline(fiStudent, cCur->ph_student->data.gender, ',');
						getline(fiStudent, cCur->ph_student->data.date, ',');
						getline(fiStudent, cCur->ph_student->data.social_ID, ',');
						getline(fiStudent, cCur->ph_student->data.password);
						cCur->ph_student->student_next = NULL;
						cCur->ph_student->ph_course_enrolled1 = NULL;
						cCur->ph_student->ph_course_enrolled2 = NULL;
						cCur->ph_student->ph_course_enrolled3 = NULL;
						//cout << yCur->ph_classes->name;
						sCur = cCur->ph_student;
					}
					else {
						sCur->student_next = new Node_student;
						getline(fiStudent, sCur->student_next->data.No, ',');
						getline(fiStudent, sCur->student_next->data.ID, ',');
						getline(fiStudent, sCur->student_next->data.first_name, ',');
						getline(fiStudent, sCur->student_next->data.lastname, ',');
						getline(fiStudent, sCur->student_next->data.gender, ',');
						getline(fiStudent, sCur->student_next->data.date, ',');
						getline(fiStudent, sCur->student_next->data.social_ID, ',');
						getline(fiStudent, sCur->student_next->data.password);
						sCur->student_next->student_next = NULL;
						sCur->student_next->ph_course_enrolled1 = NULL;
						sCur->student_next->ph_course_enrolled2 = NULL;
						sCur->student_next->ph_course_enrolled3 = NULL;
						//cout << cCur->name;
						sCur = sCur->student_next;
					}
				}
				fiStudent.close();
			}
			
			cCur = cCur->class_next;
		}
		yCur = yCur->year_next;
		fiStudent.close();
	}

	//Load khóa học
	fstream check_semester("StudentData\\" + current_year->name.substr(2, 2) + "\\Save\\SemesterCreated.txt");
	if (check_semester.is_open())
	{
		add_semester(current_year->ph_semester);
		int count = 1;
		while (count != 4)
		{
			//Load khoa hoc vao semester dong thoi add hoc sinh dang ki khoa hoc
				fstream check_course_added("StudentData\\" + current_year->name.substr(2, 2) + "\\Save\\"+ "Semester " + to_string(count) + "_courseadded.txt");
				if (check_course_added.is_open())
				{
					Node_semester* pc_semester = find_semester(current_year->ph_semester, to_string(count));
					add_course(pc_semester->ph_course, "Semester " + to_string(count), current_year->name,0);
					//Load hoc sinh dang ky
					fstream check_enrolled_student("SaveCoursesData\\Semester " + to_string(count) + "\\Courses.txt", ios::in);
					if (check_enrolled_student.is_open())
					{
						while (!check_enrolled_student.eof())
						{
							string course_name;
							check_enrolled_student >> course_name;
							Node_course* course_being_added = find_course_byname(pc_semester->ph_course, course_name);
							ifstream infor("SaveCoursesData\\Semester " + to_string(count) + "\\" + course_name + ".csv", ios::in);
							while (!infor.eof())
							{
								string trash;
								long mssv;
								getline(infor, trash, ',');
								infor >> mssv;
								Node_student* student = find_node_student_for_login_account(mssv, ph_y);
								check_time_for_semester(current_year);
								if(count == 1)
								add_enrolled_course(student->ph_course_enrolled1, course_being_added);
								if (count == 2)
								add_enrolled_course(student->ph_course_enrolled2, course_being_added);
								if (count == 3)
								add_enrolled_course(student->ph_course_enrolled3, course_being_added);
								add_enrolled_student(course_being_added->ph_student_enrolled, student);
								getline(infor, trash);
							}
						}
					}
				}
				check_course_added.close();
				count++;
		}
	}
	check_semester.close();
	//Load diem
	if (update == 1)
		updateScoreBoardOfACourse(current_year);
	//Load cac bien khac
	fstream time("StudentData\\Save\\time.txt");
		time >> now;
		time.close();
	fstream update1("StudentData\\Save\\time.txt");
		update1 >> update;
		update1.close();
}
void saveTeacherData(Node_teacher*& head) {
	fstream fs;
	fs.open("GiaoVu.csv", ios::out | ios::trunc);
	while (head) {
		fs << head->mail << "," << head->fullname << "," << head->date << "," << head->cccd << "," << head->pass;
		head = head->teacher_next;
		if (head) fs << endl;
	}
	fs.close();
}
// Các hàm tổng hợp ingiaodien
void print_student_section(int choose);
void print_after_year_section(int choose, string year_name);
void print_teacher_setting_section(int choose);
void print_year_section(int choose);
void ingiaodien_creating_year(Node_year* current_year, Node_year* ph_year, int choose, Node_teacher* teacher_login)
{
	check_time_for_semester(current_year);
	print_duongthang(25, 1, 62);
	print_duongngang(2, 5, 23);
	print_duongngang(26, 5, 208);
	check_time_for_semester(current_year);
	print_current_time(208, 60);
	if (current_year != NULL && current_year->ph_semester != NULL)
	{
		print_fill_square(183, 60, 14, 3, 15, "Semester " + to_string(current_year->semestercount));
		print_semester_start_end_time(current_year);
	}
	if (ph_year != NULL)
		print_fill_square(196, 60, 13, 3, 15, current_year->name);
	text(105, 3, "BEING LOGGED IN BY " + teacher_login->mail, 0, 15);
	print_Viennen(235, 63);
	print_year_section(choose);
}
void ingiaodien_after_creating_year(Node_year* year_choose, int choose, Node_teacher* teacher_login)
{
	check_time_for_semester(year_choose);
	print_duongthang(25, 1, 62);
	print_duongngang(2, 5, 23);
	print_duongngang(26, 5, 208);
	print_current_time(208, 60);
	print_Viennen(235, 63);
	check_time_for_semester(year_choose);
	if (year_choose != NULL && year_choose->ph_semester != NULL)
	{
		print_fill_square(183, 60, 14, 3, 15, "Semester " + to_string(year_choose->semestercount));
		print_semester_start_end_time(year_choose);
	}
	print_fill_square(196, 60, 13, 3, 15, year_choose->name);
	text(105, 3, "BEING LOGGED IN BY " + teacher_login->mail, 0, 15);
	print_after_year_section(choose, year_choose->name);
}
void ingiaodien_student(Node_year* current_year, Node_year* ph_year, Node_student* student_login, int choose)
{
	check_time_for_semester(current_year);
	print_duongthang(25, 1, 62);
	print_duongngang(2, 5, 23);
	print_duongngang(26, 5, 208);
	print_current_time(208, 60);
	if (current_year != NULL && current_year->ph_semester != NULL)
	{
		print_fill_square(183, 60, 14, 3, 15, "Semester " + to_string(current_year->semestercount));
		print_semester_start_end_time(current_year);
	}
	if (ph_year != NULL)
		print_fill_square(196, 60, 13, 3, 15, current_year->name);
	text(112, 3, "BEING LOGGED IN BY " + student_login->data.ID, 0, 15);
	print_Viennen(235, 63);
	print_student_section(choose);
}
void ingiaodien_setting(Node_year* current_year, Node_year* ph_year, int choose, Node_teacher* teacher_login)
{
	check_time_for_semester(current_year);
	print_duongthang(25, 1, 62);
	print_duongngang(2, 5, 23);
	print_duongngang(26, 5, 208);
	print_current_time(208, 60);
	if (current_year != NULL && current_year->ph_semester != NULL)
	{
		print_fill_square(183, 60, 14, 3, 15, "Semester " + to_string(current_year->semestercount));
		print_semester_start_end_time(current_year);
	}
	if (ph_year != NULL)
		print_fill_square(196, 60, 13, 3, 15, current_year->name);
	text(105, 3, "BEING LOGGED IN BY " + teacher_login->mail, 0, 15);
	print_Viennen(235, 63);
	print_teacher_setting_section(choose);
}
//Menu
void changePassword(Node_student*& a) {
	print_type_in_box(30, 10, "Type in your new password", 30);
	string b; cin >> b;
	a->data.password = b;
	print_double_square(30, 15, 24, 3, 15, "New password accepted!");
}
void teacher_change_password(Node_teacher* teacher_login)
{
	print_type_in_box(30, 10, "Type in your new password", 30);
	cin >> teacher_login->pass;
	print_double_square(30, 15, 24, 3, 15, "New password accepted!");
}
void print_student_section(int choose)
{
	text(4, 3, " ENROLLING SECTION ", 1, 11);
	//x,y,length,width,led,color (square)
	//x,y,text,led,color (text)
	int x = 3, y = 10;
	if (choose == 1)
		print_double_square(x, y, 22, 3, 12, "ENROLL COURSE");
	else
		print_double_square(x, y, 22, 3, 15, "ENROLL COURSE");
	y += 5;
	if (choose == 2)
		print_double_square(x, y, 22, 3, 12, "VIEW ENROLLED COURSE");
	else
		print_double_square(x, y, 22, 3, 15, "VIEW ENROLLED COURSE");
	y += 5;
	if (choose == 3)
		print_double_square(x, y, 22, 3, 12, "DELETE ENROLL COURSE");
	else
		print_double_square(x, y, 22, 3, 15, "DELETE ENROLL COURSE");
	y += 5;
	if (choose == 4)
		print_double_square(x, y, 22, 3, 12, "VIEW SCOREBOARD");
	else
		print_double_square(x, y, 22, 3, 15, "VIEW SCOREBOARD");
	y += 5;
	if (choose == 5)
		print_double_square(x, y, 22, 3, 12, "CHANGE PASSWORD");
	else
		print_double_square(x, y, 22, 3, 15, "CHANGE PASSWORD");
	y += 5;
	if (choose == 6)
		print_double_square(x, y, 22, 3, 12, "VIEW PROFILE");
	else
		print_double_square(x, y, 22, 3, 15, "VIEW PROFILE");
	y += 5;
	if (choose == 7)
		print_double_square(x, y, 22, 3, 12, "Exit!");
	else
		print_double_square(x, y, 22, 3, 15, "Exit!");

}
void print_year_section(int choose)
{
	text(4, 3, "SCHOOL YEAR SECTION", 1, 11);
	//x,y,length,width,led,color (square)
	//x,y,text,led,color (text)
	int x = 3, y = 10;
	if (choose == 1)
		print_double_square(x, y, 22, 3, 12, "CREATE SCHOOL YEAR");
	else
		print_double_square(x, y, 22, 3, 15, "CREATE SCHOOL YEAR");
	y += 5;
	if (choose == 2)
		print_double_square(x, y, 22, 3, 12, "CONTINUE");
	else
		print_double_square(x, y, 22, 3, 15, "CONTINUE");
	y += 5;
	if (choose == 3)
		print_double_square(x, y, 22, 3, 12, "VIEW CLASSES");
	else
		print_double_square(x, y, 22, 3, 15, "VIEW CLASSES");
	y += 5;
	if (choose == 4)
		print_double_square(x, y, 22, 3, 12, "VIEW STUDENTS");
	else
		print_double_square(x, y, 22, 3, 15, "VIEW STUDENTS");
	y += 5;
	if (choose == 5)
		print_double_square(x, y, 22, 3, 12, "VIEW COURSES");
	else
		print_double_square(x, y, 22, 3, 15, "VIEW COURSES");
	y += 5;
	if (choose == 6)
		print_double_square(x, y, 22, 3, 12, "EXPORT COURSES INFO");
	else
		print_double_square(x, y, 22, 3, 15, "EXPORT COURSES INFO");
	y += 5;
	if (choose == 7)
		print_double_square(x, y, 22, 3, 12, "UPDATE SCOREBOARD");
	else
		print_double_square(x, y, 22, 3, 15, "UPDATE SCOREBOARD");
	y += 5;
	if (choose == 8)
		print_double_square(x, y, 22, 3, 12, "VIEW SCOREBOARD");
	else
		print_double_square(x, y, 22, 3, 15, "VIEW SCOREBOARD");
	y += 5;
	if (choose == 9)
		print_double_square(x, y, 22, 3, 12, "Exit!");
	else
		print_double_square(x, y, 22, 3, 15, "Exit!");

}
void print_teacher_setting_section(int choose)
{
	int x = 3, y = 10;
	if (choose == 1)
		print_double_square(x, y, 22, 3, 12, "START EDITING");
	else
		print_double_square(x, y, 22, 3, 15, "START EDITING");
	y += 5;
	if (choose == 2)
		print_double_square(x, y, 22, 3, 12, "CHANGE PASSWORD");
	else
		print_double_square(x, y, 22, 3, 15, "CHANGE PASSWORD");
	y += 5;
	if (choose == 3)
		print_double_square(x, y, 22, 3, 12, "VIEW PROFILE");
	else
		print_double_square(x, y, 22, 3, 15, "VIEW PROFILE");
	y += 5;
	if (choose == 4)
		print_double_square(x, y, 22, 3, 12, "EXIT!");
	else
		print_double_square(x, y, 22, 3, 15, "EXIT!");
}
void print_after_year_section(int choose, string year_name)
{
	text(9, 3, year_name, 1, 11);
	//x,y,length,width,led,color (square)
	//x,y,text,led,color (text)
	int x = 3, y = 10;
	if (choose == 1)
		print_double_square(x, y, 22, 3, 12, "CREATE CLASS");
	else
		print_double_square(x, y, 22, 3, 15, "CREATE CLASS");
	y += 5;
	if (choose == 2)
		print_double_square(x, y, 22, 3, 12, "DELETE CLASS");
	else
		print_double_square(x, y, 22, 3, 15, "DELETE CLASS");
	y += 5;
	if (choose == 3)
		print_double_square(x, y, 22, 3, 12, "ADD STUDENT");
	else
		print_double_square(x, y, 22, 3, 15, "ADD STUDENT");
	y += 5;
	if (choose == 4)
		print_double_square(x, y, 22, 3, 12, "ADD SEMESTERS");
	else
		print_double_square(x, y, 22, 3, 15, "ADD SEMESTERS");
	y += 5;
	if (choose == 5)
		print_double_square(x, y, 22, 3, 12, "ADD COURSE");
	else
		print_double_square(x, y, 22, 3, 15, "ADD COURSE");
	y += 5;
	if (choose == 6)
		print_double_square(x, y, 22, 3, 12, "DELETE COURSE");
	else
		print_double_square(x, y, 22, 3, 15, "DELETE COURSE");
	y += 5;
	if (choose == 7)
		print_double_square(x, y, 22, 3, 12, "Exit!");
	else
		print_double_square(x, y, 22, 3, 15, "Exit!");
}
void print_teacher_after_creating_year_menu(Node_year*& year_choose, Node_teacher *teacher_login)
{
	int choose = 1;	char move;
	do {
		system("CLS");
		print_after_year_section(choose, year_choose->name);
		do {
			ingiaodien_after_creating_year(year_choose, choose, teacher_login);
			move = _getch();
			if (move == 'w' || move == 72)
				if (choose > 1)
					choose--;
			if (move == 's' || move == 80)
				if (choose < 7)
					choose++;
		} while (move != 13);

		if (choose == 1)
		{
			string class_name;
			print_type_in_box(30, 10, "Type class name", 11);
			cin >> class_name;
			if (check_class_duplicate(year_choose->ph_classes, class_name))
			{
				add_class(year_choose->ph_classes, class_name);
				print_double_square(30, 15, 25, 3, 15, "Create class succeeded");
			}
			else print_double_square(30, 15, 15, 3, 15, "Not accepted!");
			_getch();
		}
		//Delete class
		if (choose == 2)
		{
			if (year_choose->ph_classes != NULL)
			{
				print_class(year_choose->ph_classes);
				char class_no1;
				Node_class* class_choose;
				print_type_in_box(30, 10, "Type class number", 5);
				cin >> class_no1;
				if (class_no1 > '9' || class_no1 < '1')
				{
					print_double_square(30, 15, 13, 3, 15, "Wrong input");
					_getch();
					continue;
				}
				int class_no = class_no1 - 48;
				class_choose = find_class(year_choose->ph_classes, class_no);
				if (class_choose == NULL)
					print_double_square(30, 15, 32, 3, 15, "Class not exists or not found!");
				if (class_choose != nullptr)
				{
					delete_specific_class(year_choose->ph_classes, class_choose);
					print_double_square(30, 15, 32, 3, 15, "Delete class succeeded!");
				}
			}
			else print_double_square(30, 10, 33, 3, 15, "There is no any class to delete");
			_getch();
		}
		//Add Students
		if (choose == 3)
		{
			if (year_choose->ph_classes != NULL)
			{
				print_class(year_choose->ph_classes);
				char class_no1;
				Node_class* class_choose;

				print_type_in_box(30, 10, "Choose class to add students", 5);
				cin >> class_no1;
				if (class_no1 > '9' || class_no1 < '1')
				{
					print_double_square(30, 15, 13, 3, 15, "Wrong input");
					_getch();
					continue;
				}
				int class_no = class_no1 - 48;
				class_choose = find_class(year_choose->ph_classes, class_no);
				if (class_choose == NULL)
					print_double_square(30, 15, 32, 3, 15, "Class not exists or not found!");
				if (class_choose != NULL)
					add_1st_student(class_choose->ph_student, class_choose->name, year_choose->name);

			}
			else print_double_square(30, 10, 31, 3, 15, "There is no any class to add");
			_getch();
		}
		//Add semester
		if (choose == 4)
		{
			if (year_choose->ph_semester == NULL)
			{
				print_double_square(30, 10, 28, 3, 15, "Create semesters succeeded");
				add_semester(year_choose->ph_semester);
			}
			else print_double_square(30, 10, 29, 3, 15, "Semesters have been created");
			_getch();
		}
		//Add course
		if (choose == 5)
		{
			if (year_choose->ph_semester != nullptr)
			{
				print_semester(year_choose->ph_semester);
				Node_semester* semester_choose;
				string no;
				print_type_in_box(30, 10, "Choose semester number", 5);
				cin >> no;

				semester_choose = find_semester(year_choose->ph_semester, no);
				if (semester_choose == NULL)
					print_double_square(30, 15, 34, 3, 15, "Semester not exists or not found!");
				if (semester_choose != NULL)
				{
					add_course(semester_choose->ph_course, semester_choose->semester_no, year_choose->name,1);
					print_double_square(30, 15, 26, 3, 15, "Create courses succeeded");
				}
			}
			else print_double_square(30, 10, 30, 3, 15, "No semester has been created");
			_getch();
		}
		//Delete course
		if (choose == 6)
		{
			if (year_choose->ph_semester != nullptr)
			{
				print_semester(year_choose->ph_semester);
				Node_semester* semester_choose;
				string semester_no;

				print_type_in_box(30, 10, "Choose semester number", 5);
				cin >> semester_no;
				semester_choose = find_semester(year_choose->ph_semester, semester_no);
				if (semester_choose == NULL)
					print_double_square(30, 15, 35, 3, 15, "Semester not exists or not found!");
				if (semester_choose != NULL)
					if (semester_choose->ph_course != NULL)
					{
						print_course(semester_choose->ph_course);
						char course_no1;
						Node_course* course_choose;

						print_type_in_box(30, 15, "Choose course to delete", 5);
						cin >> course_no1;
						if (course_no1 > '9' || course_no1 < '1')
						{
							print_double_square(30, 15, 13, 3, 15, "Wrong input");
							_getch();
							continue;
						}
						int course_no = course_no1 - 48;
						course_choose = find_course(semester_choose->ph_course, course_no);
						if (course_choose == NULL)
							print_double_square(30, 20, 33, 3, 15, "Course not exists or not found!");
						if (course_choose != NULL)
						{
							delete_specific_course(semester_choose->ph_course, course_choose);
							print_double_square(30, 20, 25, 3, 15, "Delete course succeeded");
						}
					}
					else print_double_square(30, 15, 35, 3, 15, "There is no any course to delete!");
			}
			else print_double_square(30, 10, 30, 3, 15, "No semester has been created");
			_getch();
		}

	} while (choose != 7);
}
void print_teacher_creating_year_menu(Node_year*& ph_year, Node_year*& current_year, Node_teacher *teacher_login)
{
	string year_name;
	int choose = 1;	char move;

	do {
		system("CLS");
		print_year_section(choose);
		do {
			ingiaodien_creating_year(current_year, ph_year, choose, teacher_login);
			move = _getch();
			if (move == 'w' || move == 72)
				if (choose > 1)
					choose--;
			if (move == 's' || move == 80)
				if (choose < 9)
					choose++;
		} while (move != 13);
		//Create year
		if (choose == 1)
		{
			if (ph_year == NULL || check_year_end(current_year))
			{
				print_double_square(30, 10, 33, 3, 15, "Type year name(Ex: 2021-2022)");
				print_double_square(63, 10, 13, 3, 15, "\0");
				gotoXY(65, 11);
				cin >> year_name;
				if (check_year_name_appropriate(year_name) && check_year_duplicate(ph_year, year_name))
				{
					print_double_square(30, 15, 13, 3, 15, "Accepted!");
					string text = "Have been created: " + year_name;
					print_double_square(43, 15, 33, 3, 15, text);
					add_year(ph_year, year_name, current_year);
					reset_student(ph_year);
				}
				else print_double_square(30, 15, 15, 3, 15, "Not Accepted!");
			}
			_getch();
		}
		//Continue
		if (choose == 2 && ph_year != NULL)
		{
			print_teacher_after_creating_year_menu(current_year, teacher_login);
			continue;
		}
		//View class
		if (choose == 3 && ph_year != NULL)
		{
			if (ph_year->ph_classes != NULL)
				viewAllClass(ph_year);
			else print_double_square(30, 10, 31, 3, 15, "There is no any class to view");
			_getch();
		}
		//View student
		if (choose == 4 && ph_year != NULL)
		{
			char choose1;
			print_double_square(30, 10, 28, 3, 15, "1.View students in a class");
			print_double_square(30, 15, 29, 3, 15, "2.View students in a course");
			print_type_in_box(30, 20, "Your option", 5);
			cin >> choose1;
			if (choose1 > '2' || choose1 < '1')
			{
				print_double_square(30, 25, 13, 3, 15, "Wrong input");
				_getch();
				continue;
			}
			int choose = choose1 - 48;
			if (choose == 1)
			{
				if (ph_year->ph_classes != NULL)
				{
					char class_no1;
					char year_no1;
					viewAllClass(ph_year);
					print_type_in_box(30, 25, "Choose a school year", 5);
					cin >> year_no1;
					if (year_no1 > '9' || year_no1 < '1')
					{
						print_double_square(30, 30, 13, 3, 15, "Wrong input");
						_getch();
						continue;
					}
					int year_no = year_no1 - 48;
					Node_year* year_choose = find_year(ph_year, year_no);
					if (year_choose != nullptr)
					{
						print_type_in_box(30, 30, "Choose a class", 5);
						cin >> class_no1;
						if (class_no1 > '9' || class_no1 < '1')
						{
							print_double_square(30, 35, 13, 3, 15, "Wrong input");
							_getch();
							continue;
						}
						int class_no = class_no1 - 48;
						Node_class* class_choose = find_class(year_choose->ph_classes, class_no);
						if (class_choose == NULL)
							print_double_square(30, 35, 32, 3, 15, "Class not exists or not found!");
						if (class_choose != NULL)
							if (class_choose->ph_student != NULL)
								viewAllStudentInAClass(class_choose->ph_student);
							else print_double_square(30, 35, 40, 3, 15, "This class has not been added students");
					} else 	print_double_square(30, 30, 31, 3, 15, "Year not exists or not found!");
					
				}
				else print_double_square(30, 25, 31, 3, 15, "There is no any class to view");
			}
			else // choose == 2
			{
				if (current_year->ph_semester != NULL)
				{
					check_time_for_semester(current_year);

					Node_semester* semester_choose = nullptr;
					if (current_year->semestercount == 1)
					{
						semester_choose = find_semester(current_year->ph_semester, "1");
						print_course(semester_choose->ph_course);

					}
					if (current_year->semestercount == 2)
					{
						semester_choose = find_semester(current_year->ph_semester, "2");
						print_course(semester_choose->ph_course);

					}
					if (current_year->semestercount == 3)
					{
						semester_choose = find_semester(current_year->ph_semester, "3");
						print_course(semester_choose->ph_course);
					}
					print_type_in_box(30, 25, "Choose a course", 5);
					char no1;
					cin >> no1;
					if (no1 > '9' || no1 < '1')
					{
						print_double_square(30, 30, 13, 3, 15, "Wrong input");
						_getch();
						continue;
					}
					int no = no1 - 48;
					Node_course* course_choose = find_course(semester_choose->ph_course, no);
					if (course_choose->ph_student_enrolled != NULL)
						viewListofstudentsincourse(course_choose->ph_student_enrolled);
					else
					{
						print_double_square(30, 30, 45, 3, 15, "Course has not been enrolled by any student");
					}
				}
				else print_double_square(30, 30, 33, 3, 15, "Semesters have not been created");

			}
			_getch();
		}
		//View course
		if (choose == 5 && ph_year != NULL)
		{
			if (current_year->ph_semester != NULL)
			{
				check_time_for_semester(current_year);
				Node_semester* semester_choose;
				if (current_year->semestercount == 1)
				{
					semester_choose = find_semester(current_year->ph_semester, "1");
				}
				else if (current_year->semestercount == 2)
				{
					semester_choose = find_semester(current_year->ph_semester, "2");

				}
				else {
					semester_choose = find_semester(current_year->ph_semester, "3");

				}
				viewListofcourse(semester_choose->ph_course);

			}
			else print_double_square(30, 10, 32, 3, 15, "There is no any course to view");
			_getch();
		}
		//Export
		if (choose == 6)
		{
			if (check_not_end_semester(current_year,1))
			{
				Node_semester* semester_choose = nullptr;
				if (current_year->semestercount == 1)
					semester_choose = find_semester(current_year->ph_semester, "1");
				if (current_year->semestercount == 2)
					semester_choose = find_semester(current_year->ph_semester, "2");
				if (current_year->semestercount == 3)
					semester_choose = find_semester(current_year->ph_semester, "3");
				export_studentIncourse_to_csv(semester_choose->ph_course, current_year);
				print_double_square(30, 10, 19, 3, 15, "Export succeeded!");
			}
			_getch();
		}
		//Update scoreboard
		if (choose == 7)
		{
			if (check_not_end_semester(current_year,1))
			{
				updateScoreBoardOfACourse(current_year);
				update = 1;
			}
			_getch();
		}
		if (choose == 8)
		{
			if (check_not_end_semester(current_year,1))
			{
				if (update)
				{
					print_double_square(30, 10, 31, 3, 15, "1.View scoreboard of a course");
					print_double_square(30, 15, 30, 3, 15, "2.View scoreboard of a class");
					print_type_in_box(30, 20, "Your option", 5);
					char choose1;  cin >> choose1;
					if (choose1 > '2' || choose1 < '1')
					{
						print_double_square(30, 25, 13, 3, 15, "Wrong input");
						_getch();
						continue;
					}
					int choose = choose1 - 48;
					if (choose == 1)
						viewScoreBoardOfACourse(current_year);
					else
					{
						if (ph_year->ph_classes != NULL)
						{
							char class_no1;
							char year_no1;
							viewAllClass(ph_year);
							print_type_in_box(30, 25, "Choose a school year", 5);
							cin >> year_no1;
							if (year_no1 > '9' || year_no1 < '1')
							{
								print_double_square(30, 30, 13, 3, 15, "Wrong input");
								_getch();
								continue;
							}
							int year_no = year_no1 - 48;
							Node_year* year_choose = find_year(ph_year, year_no);
							print_type_in_box(30, 30, "Choose a class", 5);
							cin >> class_no1;
							if (class_no1 > '9' || class_no1 < '1')
							{
								print_double_square(30, 35, 13, 3, 15, "Wrong input");
								_getch();
								continue;
							}
							int class_no = class_no1 - 48;
							Node_class* class_choose = find_class(year_choose->ph_classes, class_no);
							if (class_choose == NULL)
								print_double_square(30, 35, 32, 3, 15, "Class not exists or not found!");
							if (class_choose != NULL)
								viewScoreBoardOfAClass(class_choose, current_year);
						}
						else print_double_square(30, 25, 31, 3, 15, "There is no any class to view");
					}
				}
				else
					print_double_square(30, 10, 36, 3, 15, "Scoreboards have not been updated!");
			}
			_getch();
		}

	} while (choose != 9);
}
void print_menu_for_student(long a, Node_year*& ph_year, Node_year*& current_year)
{
	system("CLS");
	if (ph_year == nullptr || ph_year->ph_classes == NULL || current_year->ph_classes == NULL)
	{
		print_duongthang(25, 1, 62);
		print_duongngang(2, 5, 23);
		print_duongngang(26, 5, 208);
		print_current_time(208, 60);
		print_Viennen(235, 63);
		print_student_section(0);
		print_double_square(30, 10, 25, 3, 15, "Can not find your data!");
		print_double_square(30, 15, 31, 3, 15, "Please contact for supporting");
		_getch();
		return;
	}
	Node_student* student_login = find_node_student_for_login_account(a, ph_year);
	if (student_login == NULL)
	{
		print_duongthang(25, 1, 62);
		print_duongngang(2, 5, 23);
		print_duongngang(26, 5, 208);
		print_current_time(208, 60);
		print_Viennen(235, 63);
		print_student_section(0);
		print_double_square(30, 10, 25, 3, 15, "Can not find your data!");
		print_double_square(30, 15, 31, 3, 15, "Please contact for supporting");
		_getch();
		return;
	}
	else
	{
		ingiaodien_student(current_year, ph_year, student_login, 0);
		print_double_square(30, 10, 33, 3, 15, "Loading your profile completed!");
		_getch();
		int choose = 1;	char move;
		do {
			system("CLS");
			print_student_section(choose);
			do {
				ingiaodien_student(current_year, ph_year, student_login, choose);
				move = _getch();
				if (move == 'w' || move == 72)
					if (choose > 1)
						choose--;
				if (move == 's' || move == 80)
					if (choose < 7)
						choose++;
			} while (move != 13);

			if (choose == 1)
			{
				enroll_course(student_login, current_year);
				_getch();
			}
			if (choose == 2) {
				viewCourse_Student(student_login, current_year);
				_getch();
			}
			if (choose == 3)
			{
				if (!check_not_end_semester(current_year,0))
				deleteEnrolledCourse(student_login, current_year);
				_getch();
			}
			if (choose == 4)
			{
				if(check_not_end_semester(current_year,1))
				viewScoreBoardByStudent(student_login, current_year);
				_getch();
			}
			if (choose == 5)
			{
				changePassword(student_login);
				_getch();
			}
			if (choose == 6)
			{
				view_profile_student(student_login);
				_getch();
			}
		} while (choose != 7);
	}
	savePassword(ph_year);
}
void print_teacher_setting(Node_year*& ph_year, Node_year*& current_year, Node_teacher *teacher_login, Node_teacher *ph_teacher)
{
	system("CLS");
	print_double_square(30, 10, 33, 3, 15, "Loading your profile completed!");
	ingiaodien_setting(current_year,ph_year, 0, teacher_login);
	_getch();
	int choose = 1;	char move;
	do {
		system("CLS");
		print_teacher_setting_section(choose);
		do {
			
			ingiaodien_setting(current_year, ph_year, choose, teacher_login);
			move = _getch();
			if (move == 'w' || move == 72)
				if (choose > 1)
					choose--;
			if (move == 's' || move == 80)
				if (choose < 4)
					choose++;
		} while (move != 13);

		if (choose == 1)
		{
			print_teacher_creating_year_menu(ph_year, current_year, teacher_login);
		}
		if (choose == 2) {
			teacher_change_password(teacher_login);
			saveTeacherData(ph_teacher);
			_getch();
		}
		if (choose == 3) {
			view_profile_teacher(teacher_login);
			_getch();
		}
	} while (choose != 4);
}
//Login
void print_username_password(int choose)
{
	//x,y,length,width,led,color (square)
	//x,y,text,led,color (text)
	if (choose == 1)
		print_double_square(66, 26, 40, 3, 12, "\0");
	else
		print_double_square(66, 26, 40, 3, 15, "\0");
	text(67, 27, "USERNAME: ", 1, 15);

	if (choose == 2)
		print_double_square(66, 31, 40, 3, 12, "\0");
	else
		print_double_square(66, 31, 40, 3, 15, "\0");
	text(67, 32, "PASSWORD: ", 1, 15);
	if (choose == 3)
		print_double_square(78, 36, 17, 1, 12, "Login");
	else
		print_double_square(78, 36, 17, 1, 15, "Login");

	if (choose == 4)
		print_double_square(78, 39, 17, 1, 12, "Exit!");
	else
		print_double_square(78, 39, 17, 1, 15, "Exit!");
}
int login(string a, string s1){
	if (a[0] == '1' || a[0] == '2' || a[0] == '3' || a[0] == '4' || a[0] == '5' || a[0] == '6' || a[0] == '7' || a[0] == '8' || a[0] == '9' || a[0] == '0') {
		long id = stol(a);
		fstream fs;
		string b = a;
		int cnt = 1;
		bool acp = false;
		bool end = true;
		//	string *chatluong = { "NULL","NULL","NULL","NULL","NULL","APCS","VP","CLC" };
		string* chatLuong = new string[8];
		for (int i = 0; i <= 4; i++) {
			chatLuong[i] = "NULL";
		}
		chatLuong[5] = "APCS";
		chatLuong[6] = "VP";
		chatLuong[7] = "CLC";
		while (end) {
			fs.open("StudentData\\" + to_string(id / 1000000) + "\\" + to_string(id / 1000000) + chatLuong[(id / 1000) % 10] + to_string(cnt) + ".csv", ios::in);
			if (!fs.is_open()) end = false;
			else while (!fs.eof()) {
				fs.ignore();
				fs.ignore();
				string check;
				getline(fs, check, ',');
				if (check == b) {
					string pass;
					int dem = 5;
					while (dem--) {
						getline(fs, pass, ',');
					}
					getline(fs, pass);
					if (pass == s1) {
						end = false;
						acp = true;
					}
				}
				else {
					getline(fs, check);
				}
				if (acp) break;
			}
			fs.close();
			cnt++;
		}
		delete[] chatLuong;
		if (acp)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	else {
		fstream fs;
		fs.open("GiaoVu.csv");
		while (!fs.eof()) {
			string s;
			getline(fs, s, ',');
			if (s == a) {
				int dem = 3;
				string check;
				while (dem--) {
					getline(fs, check, ',');
				}
				getline(fs, check);
				if (s1 == check) {
					return 2;
				}
			}
			else getline(fs, s);

		}
		return 0;
	}
}
void print_login_status(int x1, int y1, bool succeed)
{
	if (succeed)
	{
		gotoXY(x1, ++y1);
		cout << "	 _                 _                                         _          _ ";
		gotoXY(x1, ++y1);
		cout << "	| |               (_)                                       | |        | |";
		gotoXY(x1, ++y1);
		cout << "	| |     ___   __ _ _ _ __    ___ _   _  ___ ___ ___  ___  __| | ___  __| |";
		gotoXY(x1, ++y1);
		cout << "	| |    / _ \\ / _` | | '_ \\  / __| | | |/ __/ __/ _ \\/ _ \\/ _` |/ _ \\/ _` |";
		gotoXY(x1, ++y1);
		cout << "	| |___| (_) | (_| | | | | | \\__ \\ |_| | (_| (_|  __/  __/ (_| |  __/ (_| |";
		gotoXY(x1, ++y1);
		cout << "	\\_____/\\___/ \\__, |_|_| |_| |___/\\__,_|\\___\\___\\___|\\___|\\__,_|\\___|\\__,_|";
		gotoXY(x1, ++y1);
		cout << "                __/ |                                                ";
		gotoXY(x1, ++y1);
		cout << "               |___/                                                 ";
	}
	else
	{
		x1 += 13;
		gotoXY(x1, ++y1);
		cout << "  _                 _          __      _ _          _ ";
		gotoXY(x1, ++y1);
		cout << " | |               (_)        / _|    (_) |        | |";
		gotoXY(x1, ++y1);
		cout << " | |     ___   __ _ _ _ __   | |_ __ _ _| | ___  __| |";
		gotoXY(x1, ++y1);
		cout << " | |    / _ \\ / _` | | '_ \\  |  _/ _` | | |/ _ \\/ _` |";
		gotoXY(x1, ++y1);
		cout << " | |___| (_) | (_| | | | | | | || (_| | | |  __/ (_| |";
		gotoXY(x1, ++y1);
		cout << " |______\\___/ \\__, |_|_| |_| |_| \\__,_|_|_|\\___|\\__,_|";
		gotoXY(x1, ++y1);
		cout << "               __/ |                                  ";
		gotoXY(x1, ++y1);
		cout << "              |___/                                   ";
	}
}
void print_login_section(Node_year*& ph_year, Node_year*& current_year)
{
	string mssv = "-1"; string password = "\0";
	int choose = 1;	char move;
	bool one = true, two = true;
	do {
		print_username_password(choose);
		print_current_time(140, 48);

		do {
			// 235, 63
			print_Viennen(167, 51);
			// 68, 4
			print_Login_logo(35, 2);
			move = _getch();
			if (move == 'w' || move == 72)
				if (choose > 1)
					choose--;
			if (move == 's' || move == 80)
				if (choose < 4)
					choose++;
			print_username_password(choose);
		} while (move != 13);
		if (choose == 1 && one)
		{
			gotoXY(77, 27);
			cin >> mssv;
			one = false;
		}
		if (choose == 2 && two)
		{
			gotoXY(77, 32);
			cin >> password;
			two = false;
		}
		if (choose == 3)
		{
			if (mssv != "-1" && password != "\0" && login(mssv, password) == 1)
			{
				print_login_status(47, 15, 1);
				_getch();
				print_menu_for_student(stol(mssv) , ph_year, current_year);
				system("CLS"); choose = 1;
			}
			else
			if (mssv != "-1" && password != "\0" && login(mssv, password) == 2)
			{
				Node_teacher* ph_teacher = NULL;
				add_teacher(ph_teacher);
				Node_teacher* teacher_login = find_teacher_login(mssv, ph_teacher);
				print_login_status(47, 15, 1);
				_getch();
				print_teacher_setting(ph_year, current_year, teacher_login, ph_teacher);
				system("CLS"); choose = 1;
			}
			else
			{
				print_login_status(46, 15, 0);
				_getch();
				system("CLS");
			}
			one = true; two = true;
		}
	} while (choose != 4);
}
void SetWindowSize(SHORT width, SHORT height)
{
	HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);

	SMALL_RECT WindowSize;
	WindowSize.Top = 0;
	WindowSize.Left = 0;
	WindowSize.Right = width;
	WindowSize.Bottom = height;

	SetConsoleWindowInfo(hStdout, 1, &WindowSize);
}
void SetScreenBufferSize(SHORT width, SHORT height)
{
	HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);

	COORD NewSize;
	NewSize.X = width;
	NewSize.Y = height;

	SetConsoleScreenBufferSize(hStdout, NewSize);
}
int main()
{
	SetWindowSize(235,62);
	SetScreenBufferSize(235,9001);
	Node_year* ph_year = NULL;
	Node_year* current_year = NULL;
	loadFile(ph_year, current_year);
	print_login_section(ph_year, current_year);
	saveStudentData(ph_year, current_year);
	deallocate_all_node(ph_year);
	return 0;
}

